# 报销助手智能体系统（阶段 1：制度问答原型）

企业报销助手：员工用自然语言问制度、发起报销；管理员维护制度知识库、查看记录。
本仓库当前处于**阶段 1**：不涉及 Web，用单文件脚本验证"制度文档 → 混合检索 → 带引用的回答"这条链路是否成立。

## 目录

```
reimbursement-agent/
├── docs/
│   ├── 01-requirements-review.md       需求评审：十个关键问题 + 每个答案的架构差异
│   ├── 02-architecture.md              架构选型：四层架构 / 目录结构 / 表设计 / 第一周目标
│   ├── 03-one-page-requirements.md     一页纸需求清单（v0，待十问定稿）
│   └── 04-stage1-retrieval-report.md   阶段1 验证报告（实测 recall、失败分类、下一步）
├── prototype/
│   ├── reimbursement_assistant.py      阶段1 单文件原型（BM25 + 向量 + RRF）
│   ├── requirements.txt
│   └── data/policies/                  制度 Markdown（示例）
└── evals/
    ├── cases.jsonl                     黄金问答集（25 正向 + 5 负样本）
    └── run_eval.py                     检索评测（recall@k / MRR，可做 CI 门禁）
```

## 实测成绩（离线最低配置）

| 指标 | top_k=3 | top_k=5 |
|---|---|---|
| recall | 88.0% | 92.0% |
| MRR | 0.773 | 0.781 |

测试环境**没有 jieba、没有 faiss、没有 API Key**：分词退化为中文 bigram，向量退化为词哈希。
也就是说这是下限成绩；接真 embedding 后目标 recall@5 ≥ 95%。详见 `docs/04-stage1-retrieval-report.md`。

## 快速开始

```bash
pip install -r prototype/requirements.txt
cd prototype

# 无 API Key 也能验证链路（哈希向量 + 回显 LLM，不联网）
python reimbursement_assistant.py --offline --ask "北京出差住宿标准是多少"

# 配好 .env 后走真实模型
cp ../.env.example ../.env    # 填入 LLM_API_KEY / EMBED_API_KEY
python reimbursement_assistant.py --ask "住宿超标了怎么处理" --show-prompt
python reimbursement_assistant.py            # 交互问答

# 跑检索评测（CI 门禁：recall@k < 80% 退出码为 1）
python ../evals/run_eval.py --offline --top-k 3 --show-miss
```

## 原型做了什么

1. **切片**：标题感知 + 500 字滑动窗口（overlap 50），每个切片带标题路径
2. **混合检索**：BM25（jieba 分词）+ 向量（余弦）+ **RRF 名次融合**，取 top3
3. **提示词**：片段编号 + 强制引用 + 无依据即拒答
4. **LLM**：`LLMClient` 协议 + OpenAI 兼容实现，换供应商只改 `.env`
5. **可降级**：缺 faiss → numpy 检索；缺 jieba → 中文 bigram；缺 Key → 离线回显

代码中 `【复用·阶段2 → app/xxx.py】` 注释标出了后续搬进 Web 工程的模块。

## 已知边界（阶段 1 刻意不做）

- 不做 OCR、不做审批流、不做数据库、不做权限
- 金额是否超标等**判定**交给规则引擎，RAG 只解释依据
- 离线哈希向量只用于跑通链路，不代表真实语义检索效果

## 推送此仓库到 GitHub

本机 shell 当时不可用，以下命令需在你本机执行（仓库已在本地初始化好结构，尚未 `git init`）：

```bash
cd reimbursement-agent
git init -b main
git add .
git commit -m "feat: 阶段1 制度问答原型（BM25+向量混合检索）"
gh repo create reimbursement-agent --public --source=. --remote=origin --push
# 没有 gh：先在网页建仓，然后
# git remote add origin git@github.com:<你的账号>/reimbursement-agent.git
# git push -u origin main
```
