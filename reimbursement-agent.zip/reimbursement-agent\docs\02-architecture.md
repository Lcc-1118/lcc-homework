# 架构选型：报销助手智能体系统

> 约束：FastAPI（async）+ Python 3.11+ ；LLM 走可替换的 API；制度文档向量化检索；两个角色（员工 / 管理员）。
> 技术栈：FastAPI / SQLAlchemy 2.0 (async) / PostgreSQL 16 + pgvector / FAISS（一期）/ 混合检索（BM25 + 向量，RRF 融合）。

---

## 1. 四层架构（文字版）

```
┌──────────────────────────────────────────────────────────────────────┐
│ ① 入口层  Entry Layer                                                 │
│                                                                      │
│   Web 前端(员工/管理员)     第三方 IM(钉钉/企微)      OpenAPI 调用方      │
│            │                        │                      │         │
│            └────────────┬───────────┴──────────────────────┘         │
│                         ▼                                            │
│   FastAPI 应用：路由 / 依赖注入 / JWT 鉴权 / RBAC 角色守卫             │
│   · POST /api/v1/chat            问答（SSE 流式）                     │
│   · POST /api/v1/drafts          生成报销草稿（不落库，返回预览）       │
│   · CRUD /api/v1/admin/policies  制度文档维护 + 触发向量化            │
│   · GET  /api/v1/admin/logs      会话与调用记录                      │
│   横切：CORS / 限流 / 请求追踪(trace_id) / 统一异常     ← 中间件        │
└──────────────────────────────────────────────────────────────────────┘
                                  ▼
┌──────────────────────────────────────────────────────────────────────┐
│ ② 服务层  Service Layer（业务语义，不知道"模型"是什么）                │
│                                                                      │
│   AuthService     用户/角色/职级，组织架构快照                          │
│   ChatService     会话生命周期、消息落库、上下文窗口裁剪                 │
│   PolicyService   制度文档版本管理、生效期、切片与索引任务               │
│   DraftService    报销草稿：槽位校验 → 规则校验 → 生成预审报告          │
│   LLMService     ★供应商适配（Adapter）：OpenAI 兼容 / 私有化 / Mock    │
│   EmbeddingService★向量化适配：API / 本地 bge-m3                      │
│   RetrievalService★混合检索：BM25 + 向量 + RRF，支持 as_of 时间过滤     │
│                                                                      │
│   ★ = 可替换边界。所有"外部依赖"都在服务层被包成接口，              │
│      业务层只依赖 Protocol，换供应商 = 换一个实现类 + 一行配置。        │
└──────────────────────────────────────────────────────────────────────┘
                                  ▼
┌──────────────────────────────────────────────────────────────────────┐
│ ③ 智能体编排层  Agent Orchestration（决定"下一步做什么"）              │
│                                                                      │
│   Orchestrator（意图路由：制度问答 / 报销发起 / 进度查询 / 闲聊）       │
│     ├─ QAChain        : 检索 → 拼提示词 → 生成 → 强制引用 → 拒答兜底    │
│     ├─ DraftChain     : 多轮槽位抽取 → 缺字段追问 → 规则校验 → 预审报告 │
│     ├─ ToolRegistry   : check_standard() / create_draft() / query_status│
│     └─ Guardrails     : 幻觉拦截（无引用不许给金额）、脱敏、长度控制     │
│                                                                      │
│   设计原则：一期是"确定性编排"（if 意图=问答 → QAChain），             │
│            不是自主 Agent。可预测性优先于灵活性，方便回归测试。          │
│            二期才引入 function calling 让模型自选工具。                │
└──────────────────────────────────────────────────────────────────────┘
                                  ▼
┌──────────────────────────────────────────────────────────────────────┐
│ ④ 数据模型层  Data Layer（持久化 + 索引）                             │
│                                                                      │
│   PostgreSQL 16                                                      │
│     ├─ 事务域：users / chat_sessions / messages                      │
│     │          policy_documents / policy_versions / policy_chunks    │
│     │          expense_drafts / expense_draft_items / audit_logs     │
│     └─ 向量列：policy_chunks.embedding vector(1024) + HNSW 索引       │
│                                                                      │
│   FAISS（一期，内存态，进程启动加载 .faiss + chunks.json）             │
│     → 二期切 pgvector（多实例一致性、在线增量、按版本过滤）            │
│                                                                      │
│   Redis（二期）：语义缓存 / 限流计数 / 异步任务队列（ARQ）             │
└──────────────────────────────────────────────────────────────────────┘
```

**关键取舍说明**

| 取舍 | 选择 | 理由 |
|---|---|---|
| FAISS vs pgvector | 一期 FAISS，二期 pgvector | 一期单机+离线建索引，FAISS 零运维；一旦多实例或要按 `as_of` 版本过滤，文件态索引必然失效 |
| 自主 Agent vs 确定性编排 | 确定性编排 | 报销场景要可回归、可解释；自主 Agent 的多步行为难以写测试 |
| RAG 判定 vs 规则判定 | 规则判定金额，RAG 解释依据 | LLM 不擅长算术与查表，"算错钱"是不可接受的失败模式 |
| 同步 vs 队列 | 一期同步（SSE 流式） | 引入 Celery/Redis 会让第一周跑不通，反而拖延验证 |

---

## 2. 推荐目录结构

```
reimbursement-agent/
├── app/
│   ├── main.py                     # FastAPI 实例、路由注册、生命周期（启动加载索引）
│   ├── core/
│   │   ├── config.py               # pydantic-settings：读 .env，全量配置
│   │   ├── security.py             # JWT 签发/校验、密码哈希
│   │   ├── deps.py                 # get_db / get_current_user / require_admin
│   │   ├── logging.py              # structlog 结构化日志 + trace_id
│   │   └── exceptions.py           # 统一异常与错误码
│   ├── api/
│   │   ├── v1/
│   │   │   ├── router.py           # 汇总子路由
│   │   │   ├── chat.py             # 问答（含 SSE）
│   │   │   ├── drafts.py           # 报销草稿
│   │   │   ├── policies.py         # 管理员：制度维护
│   │   │   └── admin.py            # 管理员：记录/统计
│   │   └── schemas/                # Pydantic 请求/响应模型（对外契约）
│   │       ├── chat.py
│   │       ├── draft.py
│   │       └── policy.py
│   ├── services/                   # 业务逻辑，无 HTTP 概念
│   │   ├── auth_service.py
│   │   ├── chat_service.py
│   │   ├── policy_service.py       # 版本、切片、索引任务
│   │   ├── draft_service.py
│   │   └── audit_service.py
│   ├── llm/                        # ★ 供应商适配边界
│   │   ├── base.py                 # Protocol: LLMClient.chat / EmbeddingClient.embed
│   │   ├── openai_compat.py        # 兼容 DeepSeek/Moonshot/通义/vLLM
│   │   ├── local_vllm.py           # 私有化兜底
│   │   └── factory.py              # 按 settings.LLM_PROVIDER 返回实现
│   ├── rag/
│   │   ├── chunker.py              # 标题感知 + 滑动窗口切片
│   │   ├── bm25.py                 # 纯 Python BM25Okapi
│   │   ├── vector_store.py         # FAISS 封装（后续替换 pgvector 保持同接口）
│   │   ├── retriever.py            # 混合检索 + RRF + as_of 过滤
│   │   └── prompts.py              # 提示词模板（版本化管理）
│   ├── agents/
│   │   ├── orchestrator.py         # 意图路由
│   │   ├── qa_chain.py             # 制度问答链
│   │   ├── draft_chain.py          # 填单链（二期）
│   │   ├── tools.py                # ToolRegistry
│   │   └── guardrails.py           # 无引用拦截 / 脱敏 / 拒答
│   ├── models/                     # SQLAlchemy ORM
│   │   ├── base.py
│   │   ├── user.py
│   │   ├── chat.py                 # session + message
│   │   ├── policy.py               # document + version + chunk
│   │   ├── draft.py                # draft + item
│   │   └── audit.py
│   ├── rules/                      # 差旅标准等结构化规则（表驱动）
│   │   ├── travel_standard.py
│   │   └── validators.py
│   └── db/
│       ├── session.py              # async engine / sessionmaker
│       └── migrations/             # alembic
├── data/
│   ├── policies/                   # 制度 markdown 源文件
│   └── index/                      # FAISS 索引 + chunks.json（一期）
├── scripts/
│   ├── ingest_policies.py          # 离线建索引
│   └── seed_users.py
├── evals/                          # 黄金测试集与回归
│   ├── cases.jsonl
│   └── run_eval.py                 # recall@k / 引用率 / 拒答率
├── prototype/
│   └── reimbursement_assistant.py  # ★ 阶段1 单文件原型（本仓库已含）
├── tests/
│   ├── test_chunker.py
│   ├── test_retriever.py
│   └── test_api_chat.py
├── docker-compose.yml              # postgres(pgvector) + app
├── pyproject.toml                  # uv/poetry；ruff + mypy + pytest
├── .env.example
└── README.md
```

---

## 3. 数据库表设计

> 语法为 PostgreSQL 16；一期用 SQLite 时把 `JSONB→JSON`、`vector→TEXT`、`UUID→TEXT` 降级即可。
> 每个字段后的 `--` 注释说明"为什么需要它"，而不是"它是什么"。

### 3.1 用户

```sql
CREATE TABLE users (
    id            UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    employee_no   VARCHAR(32)  UNIQUE NOT NULL,       -- 与 HR 系统对齐的业务主键
    name          VARCHAR(64)  NOT NULL,
    email         VARCHAR(128) UNIQUE,
    role          VARCHAR(16)  NOT NULL DEFAULT 'employee',  -- employee | admin
    dept_id       VARCHAR(64),                        -- 成本中心/部门，预审归口用
    job_level     VARCHAR(16),                        -- 职级：差旅标准的判定输入
    external_id   VARCHAR(128),                       -- 钉钉/企微/LDAP 映射，接 SSO 时用
    is_active     BOOLEAN      NOT NULL DEFAULT TRUE,
    created_at    TIMESTAMPTZ  NOT NULL DEFAULT now(),
    updated_at    TIMESTAMPTZ  NOT NULL DEFAULT now()
);
CREATE INDEX idx_users_dept ON users(dept_id);
```

### 3.2 会话

```sql
CREATE TABLE chat_sessions (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    user_id     UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
    title       VARCHAR(128),                  -- 取首条提问前 30 字，列表页展示
    intent      VARCHAR(32),                   -- qa | draft | status，用于统计与路由复盘
    status      VARCHAR(16) NOT NULL DEFAULT 'active',   -- active | archived
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_sessions_user_time ON chat_sessions(user_id, updated_at DESC);
```

### 3.3 消息

```sql
CREATE TABLE messages (
    id            BIGSERIAL PRIMARY KEY,
    session_id    UUID NOT NULL REFERENCES chat_sessions(id) ON DELETE CASCADE,
    role          VARCHAR(16) NOT NULL,        -- user | assistant | tool | system
    content       TEXT NOT NULL,
    citations     JSONB,                       -- [{chunk_id, doc_title, version_id, heading}] 审计要能还原"依据哪条"
    retrieval     JSONB,                       -- top-k 命中与分数，调参与 badcase 分析用
    model         VARCHAR(64),                 -- 哪次调用用的哪个模型
    prompt_version VARCHAR(16),                -- 提示词版本，回答质量回归时定位变量
    tokens_in     INT DEFAULT 0,
    tokens_out    INT DEFAULT 0,
    latency_ms    INT,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_messages_session ON messages(session_id, created_at);
```

### 3.4 报销制度（文档 / 版本 / 切片 三张表）

```sql
CREATE TABLE policy_documents (
    id          UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    title       VARCHAR(200) NOT NULL,
    category    VARCHAR(32),                   -- travel | invoice | approval | other
    status      VARCHAR(16) NOT NULL DEFAULT 'draft',  -- draft | published | archived
    current_version_id UUID,                   -- 指向 policy_versions，避免"当下是哪版"歧义
    created_by  UUID REFERENCES users(id),
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    updated_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE TABLE policy_versions (
    id              UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    document_id     UUID NOT NULL REFERENCES policy_documents(id) ON DELETE CASCADE,
    version_no      INT  NOT NULL,             -- 同文档内递增
    content_md      TEXT NOT NULL,             -- 保留原文，重建索引的唯一真相源
    checksum        CHAR(64) NOT NULL,         -- sha256，内容未变则跳过重建
    effective_from  DATE NOT NULL,             -- 制度生效日：审计用"当时适用哪版"
    effective_to    DATE,                      -- NULL = 至今有效
    indexed_at      TIMESTAMPTZ,               -- 向量化完成时间，NULL 表示待索引
    created_by      UUID REFERENCES users(id),
    created_at      TIMESTAMPTZ NOT NULL DEFAULT now(),
    UNIQUE (document_id, version_no)
);
CREATE INDEX idx_pv_effective ON policy_versions(document_id, effective_from DESC);

CREATE TABLE policy_chunks (
    id           BIGSERIAL PRIMARY KEY,
    version_id   UUID NOT NULL REFERENCES policy_versions(id) ON DELETE CASCADE,
    chunk_index  INT  NOT NULL,
    heading_path VARCHAR(400),                 -- "差旅管理 > 住宿标准 > 一线城市"，检索结果直接可读
    content      TEXT NOT NULL,
    char_count   INT  NOT NULL,
    embedding    vector(1024),                 -- bge-m3 / text-embedding-3-small(需对齐维度)
    tsv          tsvector,                     -- 关键词兜底（中文需 zhparser/pg_bigm 或走应用层 BM25）
    UNIQUE (version_id, chunk_index)
);
CREATE INDEX idx_chunks_version ON policy_chunks(version_id);
-- 二期：CREATE INDEX ON policy_chunks USING hnsw (embedding vector_cosine_ops);
```

### 3.5 报销单草稿（含明细）

```sql
CREATE TABLE expense_drafts (
    id                UUID PRIMARY KEY DEFAULT gen_random_uuid(),
    code              VARCHAR(32) UNIQUE NOT NULL,       -- 人类可读单号，客服沟通用
    user_id           UUID NOT NULL REFERENCES users(id),
    session_id        UUID REFERENCES chat_sessions(id), -- 从哪次对话产生
    status            VARCHAR(24) NOT NULL DEFAULT 'draft',
        -- draft | pending_confirm | submitted | approved | rejected | paid
    expense_type      VARCHAR(32),                       -- travel | meal | office | other
    total_amount      NUMERIC(14,2),
    currency          CHAR(3) DEFAULT 'CNY',
    trip_start        DATE,
    trip_end          DATE,
    city              VARCHAR(64),
    job_level_snapshot     VARCHAR(16),       -- 快照！职级会变，判定可复现靠它
    policy_version_ids     JSONB,             -- 预审时引用的制度版本集合
    payload           JSONB,                  -- 完整表单结构，便于字段演进不迁移
    precheck_report   JSONB,                  -- AI 预审结论：问题清单/依据条款/置信度
    rule_engine_version VARCHAR(16),          -- 规则配置版本，与制度版本配合形成完整判定上下文
    created_at        TIMESTAMPTZ NOT NULL DEFAULT now(),
    submitted_at      TIMESTAMPTZ,
    updated_at        TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_drafts_user_status ON expense_drafts(user_id, status, updated_at DESC);

CREATE TABLE expense_draft_items (
    id             BIGSERIAL PRIMARY KEY,
    draft_id       UUID NOT NULL REFERENCES expense_drafts(id) ON DELETE CASCADE,
    item_type      VARCHAR(32),                -- 住宿/交通/餐饮/其他
    amount         NUMERIC(12,2) NOT NULL,
    item_date      DATE,
    invoice_no     VARCHAR(64),                -- 脱敏前仅落库，不进提示词
    invoice_code   VARCHAR(64),
    vendor         VARCHAR(200),
    invoice_type   VARCHAR(32),                -- vat_general | vat_special | e_ticket | taxi
    verify_status  VARCHAR(16) DEFAULT 'unverified',  -- unverified | verified | failed
    ocr_confidence NUMERIC(4,3),               -- 视觉链路才有；低置信度进人工确认队列
    raw            JSONB
);
CREATE INDEX idx_items_draft ON expense_draft_items(draft_id);
```

### 3.6 审计日志（一期就要有，别等到出事）

```sql
CREATE TABLE audit_logs (
    id          BIGSERIAL PRIMARY KEY,
    actor_id    UUID REFERENCES users(id),
    action      VARCHAR(64) NOT NULL,          -- policy.publish / draft.submit / chat.ask
    object_type VARCHAR(32),
    object_id   TEXT,
    detail      JSONB,                         -- 含模型、提示词版本、引用版本，构成"可追责三元组"
    ip          INET,
    created_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);
CREATE INDEX idx_audit_time ON audit_logs(created_at DESC);
CREATE INDEX idx_audit_actor ON audit_logs(actor_id, created_at DESC);
```

**索引/检索路径**：`policy_documents → current_version_id → policy_versions(indexed_at) → policy_chunks → embedding`。
检索时先按 `effective_from <= as_of AND (effective_to IS NULL OR effective_to > as_of)` 过滤版本，再做 ANN，避免"拿新版制度回答旧单据"。

---

## 4. 第一周的最小验证目标

**一句话目标**：证明"制度文件 → 切片 → 混合检索 → 有引用的回答"这条链路在真实制度文本文档上成立，并且能被量化。

### 必须交付（4 项，缺一项这周不算过）

| # | 交付物 | 验收标准（可测） |
|---|---|---|
| 1 | 单文件原型 `prototype/reimbursement_assistant.py` | 一条命令跑通：加载制度 md → 500 字切片 → BM25+向量 RRF 融合 → top3 → 拼提示词 → 调 LLM 回答 |
| 2 | 30 条黄金问答集 `evals/cases.jsonl` | 覆盖差旅标准/发票规则/审批流程三类，含 5 条"制度里没有，应答不知道"的负样本 |
| 3 | 检索评测脚本 `evals/run_eval.py` | 输出 **recall@3 ≥ 80%**、**引用命中率 = 100%**（回答必须带 `[1][2]`）、**负样本拒答率 ≥ 80%** |
| 4 | 一页纸技术结论 | 明确写出：哪些问题检索答得好、哪些必须靠结构化规则、下阶段该不该上 pgvector |

### 一周内**不做**的事（防止范围爆炸）

- ❌ 不做 Web 前端、不做登录、不做审批流（这些不影响"链路是否成立"这个假设）
- ❌ 不做 OCR/票据解析（一期假设纯文本电子发票）
- ❌ 不做多轮填单 Agent（先用"单轮问答 + 引用"验证检索质量，检索不行，填单一定不行）
- ❌ 不接 pgvector（单机内存 FAISS 两天能跑通，先验证再换）

### 验证顺序（先便宜的，后贵的）

1. **切片质量**（半天）：人工看 20 个切片，是否一句完整规则被切断 → 调 `chunk_size/overlap`
2. **检索质量**（一天）：先只用 BM25 看 recall，再加向量看增益 → 增量才是向量化的价值证明
3. **提示词与引用**（半天）：无引用、无依据时是否老实说"不知道"
4. **端到端**（一天）：回答里的金额/比例是否与文档逐字一致（这是幻觉的高发区）

### 风险与止损线

| 风险 | 信号 | 应对 |
|---|---|---|
| 制度文档本身写得含糊（"原则上""参考市场价"） | 检索命中但无法回答具体数字 | 立即转入"规则表 + 人工确认"路线，别在 RAG 上硬调 |
| 向量化 API 不稳定/成本 | 建索引慢、频繁超时 | Embedding 走本地 bge-m3（CPU 可跑，1024 维） |
| 召回上不去 | recall@3 < 60% | 先上 rerank（bge-reranker），再考虑查询改写；不要盲目调 top_k |
