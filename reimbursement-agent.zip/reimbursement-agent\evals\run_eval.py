#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""阶段1 评测脚本：只评"检索质量"，不评"回答质量"。

为什么先评检索？
  报销助手的错误 80% 来自"没检索到正确条款"，而不是"模型不会写"。
  检索 recall 不达标时，换更大的模型、改提示词都只是在掩盖问题。

指标
----
recall@k : 正确答案所在的制度章节是否出现在 top-k 里（正向用例）
MRR      : 首个正确条目的倒数名次，衡量"排得够不够靠前"
负样本   : 制度中确实没有答案的问题，检索理应"命中率低"；这里只做提示，
           真正的"拒答"要由 LLM 判定（阶段2 接入评测流水线时补上）

用法
----
    python evals/run_eval.py --offline          # 无 Key，哈希向量（数字仅供参考）
    python evals/run_eval.py                    # 走 .env 里的真实 embedding
    python evals/run_eval.py --top-k 5 --show-miss
"""

from __future__ import annotations

import argparse
import json
import sys
from pathlib import Path

# 把 prototype/ 加入模块搜索路径，直接复用原型里的检索实现（不复制代码）
ROOT = Path(__file__).resolve().parent.parent
sys.path.insert(0, str(ROOT / "prototype"))

import reimbursement_assistant as ra  # noqa: E402


def load_cases(path: Path) -> list[dict]:
    cases = []
    for line_no, line in enumerate(path.read_text(encoding="utf-8").splitlines(), start=1):
        line = line.strip()
        if not line or line.startswith("#"):
            continue
        try:
            cases.append(json.loads(line))
        except json.JSONDecodeError as exc:
            raise SystemExit(f"{path}:{line_no} 不是合法 JSON：{exc}") from exc
    return cases


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(description="阶段1 检索评测")
    parser.add_argument("--cases", type=Path, default=ROOT / "evals" / "cases.jsonl")
    parser.add_argument("--policy", type=Path,
                        default=ROOT / "prototype" / "data" / "policies" / "company_reimbursement.md")
    parser.add_argument("--index-dir", type=Path, default=ROOT / "prototype" / "data" / "index")
    parser.add_argument("--top-k", type=int, default=3)
    parser.add_argument("--offline", action="store_true", help="不联网，用哈希向量")
    parser.add_argument("--show-miss", action="store_true", help="打印未命中的用例")
    args = parser.parse_args(argv)

    ra.load_dotenv_light(ROOT / ".env")
    ra.load_dotenv_light(ROOT / "prototype" / ".env")
    cfg = ra.Config.from_env(offline=args.offline)

    embedder = ra.make_embedder(cfg)
    chunks, retriever = ra.build_or_load_index(args.policy, cfg, embedder, args.index_dir)
    print(f"[评测] 切片 {len(chunks)} 个，top_k={args.top_k}，用例文件 {args.cases.name}\n")

    cases = load_cases(args.cases)
    positives = [c for c in cases if c.get("expect_heading")]
    negatives = [c for c in cases if not c.get("expect_heading")]

    hit = 0
    reciprocal = 0.0
    misses: list[dict] = []

    for case in positives:
        hits = retriever.search(case["question"], top_k=args.top_k)
        wanted = case["expect_heading"]
        rank = next((i for i, h in enumerate(hits, start=1) if wanted in h.chunk.heading), None)
        if rank:
            hit += 1
            reciprocal += 1.0 / rank
        else:
            misses.append({"id": case["id"], "question": case["question"], "want": wanted,
                           "got": [h.chunk.heading for h in hits]})

    recall = hit / len(positives) if positives else 0.0
    mrr = reciprocal / len(positives) if positives else 0.0

    print("=" * 72)
    print(f"recall@{args.top_k} : {recall:.1%}  ({hit}/{len(positives)})")
    print(f"MRR        : {mrr:.3f}")
    print("=" * 72)

    if misses and args.show_miss:
        print("\n未命中：")
        for m in misses:
            print(f"  {m['id']} {m['question']}\n     期望含「{m['want']}」")
            for got in m["got"]:
                print(f"     - 实得：{got.split(' > ')[-1]}")

    if negatives:
        print(f"\n负样本 {len(negatives)} 条：制度中无答案，需人工确认模型是否拒答。")
        for case in negatives:
            hits = retriever.search(case["question"], top_k=args.top_k)
            top = hits[0].chunk.heading.split(" > ")[-1] if hits else "（空）"
            print(f"  {case['id']} {case['question']}  → 最相似：{top}")

    # 退出码交给 CI 使用：recall 不达标返回 1
    threshold = 0.8
    if recall < threshold:
        print(f"\n[不达标] recall@{args.top_k} < {threshold:.0%}")
        return 1
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
